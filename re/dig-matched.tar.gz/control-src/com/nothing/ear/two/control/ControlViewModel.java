package com.nothing.ear.two.control;

import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import androidx.databinding.ObservableArrayList;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModelKt;
import com.nothing.base.adapter.CommonBindingMoreType;
import com.nothing.base.util.Logger;
import com.nothing.base.util.ext.DataExtKt;
import com.nothing.core.ext.TWSDeviceExtKt;
import com.nothing.ear.R;
import com.nothing.ear.two.core.protocol.EarTwoSppProtocol;
import com.nothing.earbase.control.BaseControlViewModel;
import com.nothing.earbase.control.ControlGestureViewModel;
import com.nothing.earbase.control.ControlNotCustomisableViewModel;
import com.nothing.earbase.control.ControlOperationViewModel;
import com.nothing.earbase.control.entity.ControlBottomEntity;
import com.nothing.earbase.control.entity.ControlConfigurationEntity;
import com.nothing.earbase.control.entity.ControlRadius;
import com.nothing.earbase.spp.BaseSppProtocol;
import com.nothing.event.log.AppBuriedPointUtils;
import com.nothing.log.FileLog;
import com.nothing.protocol.device.TWSDevice;
import com.nothing.protocol.device.TWSDeviceBuilder;
import com.nothing.protocol.model.Message;
import java.util.ArrayList;
import java.util.Date;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.Boxing;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import org.apache.commons.cli.HelpFormatter;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: ControlViewModel.kt */
/* JADX INFO: loaded from: /tmp/source/classes6.dex */
@Metadata(d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u0000 02\u00020\u0001:\u00010B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0004\b\u0004\u0010\u0005J\u0012\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016J\b\u0010\u0010\u001a\u00020\rH\u0002J\u0018\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J&\u0010\u0016\u001a\u00020\r2\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u00182\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0014\u001a\u00020\u0015H\u0002J\u0018\u0010\u001c\u001a\u00020\r2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u001d\u001a\u00020\u001eH\u0002J\u001e\u0010\u001f\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020 2\u0006\u0010!\u001a\u00020\"2\u0006\u0010\u0014\u001a\u00020\u0015J2\u0010#\u001a\u00020\r*\u00020\u00002\u0006\u0010\u0012\u001a\u00020 2\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010!\u001a\u00020\"H\u0082@\u00a2\u0006\u0002\u0010$J&\u0010%\u001a\u00020\u001e2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u001b2\u0006\u0010!\u001a\u00020\"H\u0082@\u00a2\u0006\u0002\u0010'J\b\u0010(\u001a\u00020\rH\u0016J \u0010)\u001a\u00020\r2\u0016\u0010*\u001a\u0012\u0012\u0004\u0012\u00020\u001b0+j\b\u0012\u0004\u0012\u00020\u001b`,H\u0002J \u0010-\u001a\u00020\r2\u0016\u0010*\u001a\u0012\u0012\u0004\u0012\u00020\u001b0+j\b\u0012\u0004\u0012\u00020\u001b`,H\u0002J\u0010\u0010.\u001a\u00020\r2\u0006\u0010\u001a\u001a\u00020\u0013H\u0002J\u0014\u0010/\u001a\u0004\u0018\u00010 2\b\u0010!\u001a\u0004\u0018\u00010\u001bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b\u00a8\u00061"}, d2 = {"Lcom/nothing/ear/two/control/ControlViewModel;", "Lcom/nothing/earbase/control/BaseControlViewModel;", "context", "Landroid/app/Application;", "<init>", "(Landroid/app/Application;)V", "protocol", "Lcom/nothing/ear/two/core/protocol/EarTwoSppProtocol;", "getProtocol", "()Lcom/nothing/ear/two/core/protocol/EarTwoSppProtocol;", "setProtocol", "(Lcom/nothing/ear/two/core/protocol/EarTwoSppProtocol;)V", "register", "", "extras", "Landroid/os/Bundle;", "listenerLiveData", "setGestureData", "viewModel", "Lcom/nothing/earbase/control/ControlGestureViewModel;", "dialogItemViewModel", "Lcom/nothing/earbase/control/ControlOperationViewModel;", "syncTargetNoiseMode", "gestureData", "Landroidx/databinding/ObservableArrayList;", "Lcom/nothing/base/adapter/CommonBindingMoreType;", "it", "Lcom/nothing/earbase/control/entity/ControlConfigurationEntity$Operation;", "setVisibleOrGoneNoiseSubItems", "isLeft", "", "setAncGestureData", "Lcom/nothing/ear/two/control/ControlItemViewModel;", "operation", "", "setSynDevice", "(Lcom/nothing/ear/two/control/ControlViewModel;Lcom/nothing/ear/two/control/ControlItemViewModel;Lcom/nothing/earbase/control/entity/ControlConfigurationEntity$Operation;Lcom/nothing/earbase/control/ControlOperationViewModel;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "setNoiseAnc", "option", "(Lcom/nothing/earbase/control/ControlOperationViewModel;Lcom/nothing/earbase/control/entity/ControlConfigurationEntity$Operation;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "resetGestureData", "updateRightData", "operations", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "updateLeftData", "resetGestureOperation", "addSinglePress", "Companion", "nt_ear_GoogleStoreRelease"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ControlViewModel extends BaseControlViewModel {

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    private static final int[] SUPPORT_GESTURES = {1, 2, 3, 7, 9};
    private final Application context;
    private EarTwoSppProtocol protocol;

    /* JADX INFO: renamed from: com.nothing.ear.two.control.ControlViewModel$setSynDevice$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: ControlViewModel.kt */
    @Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @DebugMetadata(c = "com.nothing.ear.two.control.ControlViewModel", f = "ControlViewModel.kt", i = {0, 0, 0, 0, 0, 0}, l = {251}, m = "setSynDevice", n = {"$this$setSynDevice", "it", "dialogItemViewModel", "gesture", "option", "operation"}, s = {"L$0", "L$1", "L$2", "L$4", "L$5", "I$0"})
    static final class C05821 extends ContinuationImpl {
        int I$0;
        Object L$0;
        Object L$1;
        Object L$2;
        Object L$3;
        Object L$4;
        Object L$5;
        int label;
        /* synthetic */ Object result;

        C05821(Continuation<? super C05821> continuation) {
            super(continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) {
            this.result = obj;
            this.label |= Integer.MIN_VALUE;
            return ControlViewModel.this.setSynDevice(null, null, null, null, 0, this);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public ControlViewModel(Application context) {
        super(context);
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        this.protocol = new EarTwoSppProtocol(null, 1, 0 == true ? 1 : 0);
    }

    /* JADX INFO: compiled from: ControlViewModel.kt */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002\u00a2\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007\u00a8\u0006\b"}, d2 = {"Lcom/nothing/ear/two/control/ControlViewModel$Companion;", "", "<init>", "()V", "SUPPORT_GESTURES", "", "getSUPPORT_GESTURES", "()[I", "nt_ear_GoogleStoreRelease"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final int[] getSUPPORT_GESTURES() {
            return ControlViewModel.SUPPORT_GESTURES;
        }
    }

    public final EarTwoSppProtocol getProtocol() {
        return this.protocol;
    }

    public final void setProtocol(EarTwoSppProtocol earTwoSppProtocol) {
        Intrinsics.checkNotNullParameter(earTwoSppProtocol, "<set-?>");
        this.protocol = earTwoSppProtocol;
    }

    @Override // com.nothing.earbase.control.BaseControlViewModel
    public void register(Bundle extras) {
        super.register(extras);
        String string = extras != null ? extras.getString("device_address") : null;
        Logger logger = Logger.INSTANCE;
        String tag = logger.getTAG();
        int depth = logger.getDepth();
        if (logger.isCanLogger(true)) {
            String str = "ControlViewModel address " + string;
            String str2 = str;
            if (str2 != null && str2.length() != 0) {
                Pair<String, String> trace = logger.getTrace(depth);
                String strComponent1 = trace.component1();
                String strComponent2 = trace.component2();
                FileLog fileLog = FileLog.INSTANCE;
                String str3 = logger.getSdf().format(new Date());
                Intrinsics.checkNotNullExpressionValue(str3, "format(...)");
                FileLog.print$default(fileLog, 4, str3, tag, str + StringUtils.SPACE + strComponent2, null, 16, null);
                if (logger.isDebug()) {
                    Log.i(tag + strComponent1, str + StringUtils.SPACE + strComponent2);
                }
            }
        }
        this.protocol = new EarTwoSppProtocol(string);
        listenerLiveData();
        getGestureData(false);
    }

    private final void listenerLiveData() {
        final TWSDeviceBuilder tWSDeviceBuilderKeyConfiguration;
        LiveData liveDataDistinctUntilChanged;
        TWSDevice tWSDevice = this.protocol.getTWSDevice();
        if (tWSDevice == null || (tWSDeviceBuilderKeyConfiguration = TWSDeviceExtKt.keyConfiguration(tWSDevice)) == null) {
            return;
        }
        final Class<ControlConfigurationEntity> cls = ControlConfigurationEntity.class;
        LiveData map = Transformations.map(tWSDeviceBuilderKeyConfiguration.getTwsDevice().getCommandCache().getLiveDataCommand(tWSDeviceBuilderKeyConfiguration.getGetCommand(), tWSDeviceBuilderKeyConfiguration.getNotifyCommand()), new Function1<Message, ControlConfigurationEntity>() { // from class: com.nothing.ear.two.control.ControlViewModel$listenerLiveData$$inlined$getLiveData$1
            /* JADX WARN: Multi-variable type inference failed */
            @Override // kotlin.jvm.functions.Function1
            public final ControlConfigurationEntity invoke(Message message) {
                byte[] payload;
                Object obj;
                ControlConfigurationEntity controlConfigurationEntity = 0;
                Object obj2 = null;
                objNewInstance = null;
                Object objNewInstance = null;
                controlConfigurationEntity = 0;
                if (message != null && (payload = message.getPayload()) != null) {
                    Class cls2 = cls;
                    try {
                        if (Intrinsics.areEqual(cls2, Integer.TYPE)) {
                            obj = (ControlConfigurationEntity) Integer.valueOf(DataExtKt.toInt$default(payload, 0, 0, 3, null));
                        } else if (Intrinsics.areEqual(cls2, Long.TYPE)) {
                            obj = (ControlConfigurationEntity) Long.valueOf(DataExtKt.toLong$default(payload, 0, 0, 3, null));
                        } else if (Intrinsics.areEqual(cls2, String.class)) {
                            Object objDecodeToString = StringsKt.decodeToString(payload);
                            if (objDecodeToString == null) {
                                throw new NullPointerException("null cannot be cast to non-null type com.nothing.earbase.control.entity.ControlConfigurationEntity");
                            }
                            obj = (ControlConfigurationEntity) objDecodeToString;
                        } else if (Intrinsics.areEqual(cls2, Boolean.TYPE)) {
                            obj = (ControlConfigurationEntity) Boolean.valueOf(DataExtKt.toInt$default(payload, 0, 0, 3, null) == 1);
                        } else if (Intrinsics.areEqual(cls2, Float.TYPE)) {
                            obj = (ControlConfigurationEntity) Float.valueOf(DataExtKt.toFloat$default(payload, 0, 0, 0, 7, null));
                        } else {
                            try {
                                objNewInstance = cls2.getConstructor(byte[].class).newInstance(payload);
                                obj2 = objNewInstance;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            obj = obj2;
                        }
                        controlConfigurationEntity = obj;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        controlConfigurationEntity = objNewInstance;
                    }
                }
                Logger logger = Logger.INSTANCE;
                Class cls3 = cls;
                Logger logger2 = logger;
                String tag = logger2.getTAG();
                int depth = logger2.getDepth();
                if (logger2.isCanLogger(true)) {
                    String str = "parseLiveData " + cls3 + StringUtils.SPACE + controlConfigurationEntity + StringUtils.SPACE;
                    String str2 = str;
                    if (str2 != null && str2.length() != 0) {
                        Pair<String, String> trace = logger2.getTrace(depth);
                        String strComponent1 = trace.component1();
                        String strComponent2 = trace.component2();
                        FileLog fileLog = FileLog.INSTANCE;
                        String str3 = logger2.getSdf().format(new Date());
                        Intrinsics.checkNotNullExpressionValue(str3, "format(...)");
                        FileLog.print$default(fileLog, 4, str3, tag, str + StringUtils.SPACE + strComponent2, null, 16, null);
                        if (logger2.isDebug()) {
                            Log.i(tag + strComponent1, str + StringUtils.SPACE + strComponent2);
                        }
                    }
                }
                return controlConfigurationEntity;
            }
        });
        if (map == null || (liveDataDistinctUntilChanged = Transformations.distinctUntilChanged(map)) == null) {
            return;
        }
        liveDataDistinctUntilChanged.observe(this, new ControlViewModel$sam$androidx_lifecycle_Observer$0(new Function1() { // from class: com.nothing.ear.two.control.ControlViewModel$$ExternalSyntheticLambda0
            @Override // kotlin.jvm.functions.Function1
            public final Object invoke(Object obj) {
                return ControlViewModel.listenerLiveData$lambda$7(this.f$0, (ControlConfigurationEntity) obj);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final Unit listenerLiveData$lambda$7(ControlViewModel controlViewModel, ControlConfigurationEntity controlConfigurationEntity) {
        if (controlConfigurationEntity == null) {
            return Unit.INSTANCE;
        }
        ObservableArrayList<CommonBindingMoreType> observableArrayList = new ObservableArrayList<>();
        ObservableArrayList<CommonBindingMoreType> observableArrayList2 = new ObservableArrayList<>();
        ControlConfigurationEntity.Operation operation = null;
        ControlConfigurationEntity.Operation operation2 = null;
        for (ControlConfigurationEntity.Operation operation3 : controlConfigurationEntity.getOperations()) {
            if (ArraysKt.contains(SUPPORT_GESTURES, operation3.getGesture())) {
                ControlItemViewModel controlItemViewModel = new ControlItemViewModel(operation3, controlViewModel.context, controlViewModel.getAddress());
                if (Intrinsics.areEqual((Object) controlItemViewModel.isLeft().get(), (Object) true)) {
                    observableArrayList.add(controlItemViewModel);
                    operation = operation3;
                } else {
                    observableArrayList2.add(controlItemViewModel);
                    operation2 = operation3;
                }
            }
        }
        if (!observableArrayList.isEmpty()) {
            controlViewModel.setControlRadius(observableArrayList);
            if (controlViewModel.getIsSystem()) {
                ArrayList arrayList = new ArrayList();
                ControlItemViewModel controlItemViewModelAddSinglePress = controlViewModel.addSinglePress(operation);
                if (controlItemViewModelAddSinglePress != null) {
                    arrayList.add(controlItemViewModelAddSinglePress);
                }
                observableArrayList.add(new ControlNotCustomisableViewModel(arrayList, controlViewModel.context, null, null, null, 28, null));
                controlViewModel.setLeftGestureData(observableArrayList);
            } else {
                controlViewModel.setLeftGestureData(observableArrayList);
                ControlNotCustomisableViewModel controlNotCustomisableViewModel = new ControlNotCustomisableViewModel(null, controlViewModel.context, null, null, null, 28, null);
                controlNotCustomisableViewModel.getTitle().set(controlViewModel.context.getString(R.string.gesture_not_customisation));
                controlViewModel.getLeftGestureData().add(controlNotCustomisableViewModel);
                ControlItemViewModel controlItemViewModelAddSinglePress2 = controlViewModel.addSinglePress(operation);
                if (controlItemViewModelAddSinglePress2 != null) {
                    controlItemViewModelAddSinglePress2.setDirection(ControlRadius.NONE);
                    controlViewModel.getLeftGestureData().add(controlItemViewModelAddSinglePress2);
                }
                controlViewModel.getLeftGestureData().add(new ControlBottomEntity());
            }
        }
        if (!observableArrayList2.isEmpty()) {
            controlViewModel.setControlRadius(observableArrayList2);
            if (controlViewModel.getIsSystem()) {
                ArrayList arrayList2 = new ArrayList();
                ControlItemViewModel controlItemViewModelAddSinglePress3 = controlViewModel.addSinglePress(operation2);
                if (controlItemViewModelAddSinglePress3 != null) {
                    arrayList2.add(controlItemViewModelAddSinglePress3);
                }
                observableArrayList2.add(new ControlNotCustomisableViewModel(arrayList2, controlViewModel.context, null, null, null, 28, null));
                controlViewModel.setRightGestureData(observableArrayList2);
            } else {
                controlViewModel.setRightGestureData(observableArrayList2);
                ControlNotCustomisableViewModel controlNotCustomisableViewModel2 = new ControlNotCustomisableViewModel(null, controlViewModel.context, null, null, null, 28, null);
                controlNotCustomisableViewModel2.getTitle().set(controlViewModel.context.getString(R.string.gesture_not_customisation));
                controlViewModel.getRightGestureData().add(controlNotCustomisableViewModel2);
                ControlItemViewModel controlItemViewModelAddSinglePress4 = controlViewModel.addSinglePress(operation2);
                if (controlItemViewModelAddSinglePress4 != null) {
                    controlItemViewModelAddSinglePress4.setDirection(ControlRadius.NONE);
                    controlViewModel.getRightGestureData().add(controlItemViewModelAddSinglePress4);
                }
                controlViewModel.getRightGestureData().add(new ControlBottomEntity());
            }
        }
        controlViewModel.getDataUpdate().postValue(new Pair<>(1, Boolean.valueOf(controlViewModel.checkHasSetValue())));
        Logger logger = Logger.INSTANCE;
        String tag = logger.getTAG();
        int depth = logger.getDepth();
        if (logger.isCanLogger(true) && "dataUpdate is loadData success".length() != 0) {
            Pair<String, String> trace = logger.getTrace(depth);
            String strComponent1 = trace.component1();
            String strComponent2 = trace.component2();
            FileLog fileLog = FileLog.INSTANCE;
            String str = logger.getSdf().format(new Date());
            Intrinsics.checkNotNullExpressionValue(str, "format(...)");
            FileLog.print$default(fileLog, 4, str, tag, "dataUpdate is loadData success " + strComponent2, null, 16, null);
            if (logger.isDebug()) {
                Log.i(tag + strComponent1, "dataUpdate is loadData success " + strComponent2);
            }
        }
        return Unit.INSTANCE;
    }

    @Override // com.nothing.earbase.control.BaseControlViewModel
    public void setGestureData(ControlGestureViewModel viewModel, ControlOperationViewModel dialogItemViewModel) {
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(dialogItemViewModel, "dialogItemViewModel");
        ControlConfigurationEntity.Operation options = viewModel.getOptions();
        if (options != null) {
            AppBuriedPointUtils.INSTANCE.controlData(options.getDevice(), options.getButton(), options.getGesture(), dialogItemViewModel.getOperation(), getIsSystem());
            BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new ControlViewModel$setGestureData$1$1(dialogItemViewModel, options, viewModel, this, null), 2, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void syncTargetNoiseMode(ObservableArrayList<CommonBindingMoreType> gestureData, ControlConfigurationEntity.Operation it, ControlOperationViewModel dialogItemViewModel) {
        ControlGestureViewModel controlGestureViewModel;
        ControlConfigurationEntity.Operation options;
        ControlConfigurationEntity.Operation options2;
        for (CommonBindingMoreType commonBindingMoreType : gestureData) {
            if ((commonBindingMoreType instanceof ControlGestureViewModel) && (options = (controlGestureViewModel = (ControlGestureViewModel) commonBindingMoreType).getOptions()) != null && it.getGesture() == options.getGesture() && (options2 = controlGestureViewModel.getOptions()) != null && dialogItemViewModel.isNoiseOperation(options2.getOperation())) {
                dialogItemViewModel.setOperation(options2.getOperation());
                Logger logger = Logger.INSTANCE;
                String tag = logger.getTAG();
                int depth = logger.getDepth();
                if (logger.isCanLogger(true)) {
                    String str = "setGestureData --> normal to  noise " + ((Object) controlGestureViewModel.getGestureName().get()) + HelpFormatter.DEFAULT_LONG_OPT_PREFIX + ((Object) controlGestureViewModel.getOperationName().get()) + StringUtils.SPACE;
                    String str2 = str;
                    if (str2 != null && str2.length() != 0) {
                        Pair<String, String> trace = logger.getTrace(depth);
                        String strComponent1 = trace.component1();
                        String strComponent2 = trace.component2();
                        FileLog fileLog = FileLog.INSTANCE;
                        String str3 = logger.getSdf().format(new Date());
                        Intrinsics.checkNotNullExpressionValue(str3, "format(...)");
                        FileLog.print$default(fileLog, 4, str3, tag, str + StringUtils.SPACE + strComponent2, null, 16, null);
                        if (logger.isDebug()) {
                            Log.i(tag + strComponent1, str + StringUtils.SPACE + strComponent2);
                        }
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setVisibleOrGoneNoiseSubItems(ControlOperationViewModel dialogItemViewModel, boolean isLeft) {
        if (dialogItemViewModel.getOperation() == 10 || dialogItemViewModel.getOperation() == 20 || dialogItemViewModel.getOperation() == 22 || dialogItemViewModel.getOperation() == 21) {
            dialogItemViewModel.getNoiseControlVisible().set(true);
            return;
        }
        ObservableArrayList<CommonBindingMoreType> leftGestureData = getLeftGestureData();
        if (!isLeft) {
            leftGestureData = getRightGestureData();
        }
        for (CommonBindingMoreType commonBindingMoreType : leftGestureData) {
            if (commonBindingMoreType instanceof ControlItemViewModel) {
                for (ControlOperationViewModel controlOperationViewModel : ((ControlItemViewModel) commonBindingMoreType).getOperationList()) {
                    if (controlOperationViewModel.getOperation() == 10 || controlOperationViewModel.getOperation() == 20 || controlOperationViewModel.getOperation() == 22 || controlOperationViewModel.getOperation() == 21) {
                        controlOperationViewModel.getNoiseControlVisible().set(false);
                    }
                }
            }
        }
    }

    public final void setAncGestureData(ControlItemViewModel viewModel, int operation, ControlOperationViewModel dialogItemViewModel) {
        ControlConfigurationEntity.Operation options;
        Intrinsics.checkNotNullParameter(viewModel, "viewModel");
        Intrinsics.checkNotNullParameter(dialogItemViewModel, "dialogItemViewModel");
        if (operation == 0 || (options = viewModel.getOptions()) == null) {
            return;
        }
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new ControlViewModel$setAncGestureData$1$1(this, options, operation, viewModel, dialogItemViewModel, null), 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:21:0x0087  */
    /* JADX WARN: Code duplicated, block: B:23:0x0091  */
    /* JADX WARN: Code duplicated, block: B:30:0x00ba  */
    /* JADX WARN: Code duplicated, block: B:32:0x00ee  */
    /* JADX WARN: Code duplicated, block: B:40:0x0178  */
    /* JADX WARN: Code duplicated, block: B:42:0x018f A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:43:0x0190  */
    /* JADX WARN: Code duplicated, block: B:53:0x01d3  */
    /* JADX WARN: Code duplicated, block: B:7:0x0018  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x008f -> B:54:0x01d4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x0098 -> B:54:0x01d4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x00a2 -> B:54:0x01d4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:43:0x0190 -> B:44:0x0198). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:53:0x01d3 -> B:54:0x01d4). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object setSynDevice(com.nothing.ear.two.control.ControlViewModel r22, com.nothing.ear.two.control.ControlItemViewModel r23, com.nothing.earbase.control.entity.ControlConfigurationEntity.Operation r24, com.nothing.earbase.control.ControlOperationViewModel r25, int r26, kotlin.coroutines.Continuation<? super kotlin.Unit> r27) {
        /*
            Method dump skipped, instruction units count: 475
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.nothing.ear.two.control.ControlViewModel.setSynDevice(com.nothing.ear.two.control.ControlViewModel, com.nothing.ear.two.control.ControlItemViewModel, com.nothing.earbase.control.entity.ControlConfigurationEntity$Operation, com.nothing.earbase.control.ControlOperationViewModel, int, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Object setNoiseAnc(ControlOperationViewModel controlOperationViewModel, ControlConfigurationEntity.Operation operation, int i, Continuation<? super Boolean> continuation) {
        return controlOperationViewModel.isNoiseOperation(operation.getOperation()) ? BaseSppProtocol.setGestureData$default(this.protocol, operation, i, 0, continuation, 4, null) : Boxing.boxBoolean(false);
    }

    @Override // com.nothing.earbase.control.BaseControlViewModel
    public void resetGestureData() {
        ArrayList<ControlConfigurationEntity.Operation> arrayList = new ArrayList<>();
        updateLeftData(arrayList);
        updateRightData(arrayList);
        BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new AnonymousClass1(arrayList, null), 2, null);
    }

    /* JADX INFO: renamed from: com.nothing.ear.two.control.ControlViewModel$resetGestureData$1, reason: invalid class name */
    /* JADX INFO: compiled from: ControlViewModel.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @DebugMetadata(c = "com.nothing.ear.two.control.ControlViewModel$resetGestureData$1", f = "ControlViewModel.kt", i = {}, l = {280, 281}, m = "invokeSuspend", n = {}, s = {})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ ArrayList<ControlConfigurationEntity.Operation> $operations;
        int label;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(ArrayList<ControlConfigurationEntity.Operation> arrayList, Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
            this.$operations = arrayList;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return ControlViewModel.this.new AnonymousClass1(this.$operations, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code restructure failed: missing block: B:14:0x0054, code lost:
        
            if (kotlinx.coroutines.BuildersKt.withContext(kotlinx.coroutines.Dispatchers.getMain(), new com.nothing.ear.two.control.ControlViewModel.AnonymousClass1.C01221(r7, r6.this$0, null), r6) == r0) goto L15;
         */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final Object invokeSuspend(Object obj) {
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                this.label = 1;
                obj = ControlViewModel.this.getProtocol().resetGestureData(this.$operations, this);
                if (obj != coroutine_suspended) {
                }
                return coroutine_suspended;
            }
            if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                if (i != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
            boolean zBooleanValue = ((Boolean) obj).booleanValue();
            this.label = 2;
        }

        /* JADX INFO: renamed from: com.nothing.ear.two.control.ControlViewModel$resetGestureData$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: compiled from: ControlViewModel.kt */
        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
        @DebugMetadata(c = "com.nothing.ear.two.control.ControlViewModel$resetGestureData$1$1", f = "ControlViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
        static final class C01221 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ boolean $result;
            int label;
            final /* synthetic */ ControlViewModel this$0;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C01221(boolean z, ControlViewModel controlViewModel, Continuation<? super C01221> continuation) {
                super(2, continuation);
                this.$result = z;
                this.this$0 = controlViewModel;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                return new C01221(this.$result, this.this$0, continuation);
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((C01221) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) {
                IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                if (this.$result) {
                    ObservableArrayList<CommonBindingMoreType> leftGestureData = this.this$0.getLeftGestureData();
                    ControlViewModel controlViewModel = this.this$0;
                    for (CommonBindingMoreType commonBindingMoreType : leftGestureData) {
                        if (commonBindingMoreType instanceof ControlGestureViewModel) {
                            controlViewModel.resetGestureOperation((ControlGestureViewModel) commonBindingMoreType);
                        }
                    }
                    ObservableArrayList<CommonBindingMoreType> rightGestureData = this.this$0.getRightGestureData();
                    ControlViewModel controlViewModel2 = this.this$0;
                    for (CommonBindingMoreType commonBindingMoreType2 : rightGestureData) {
                        if (commonBindingMoreType2 instanceof ControlGestureViewModel) {
                            controlViewModel2.resetGestureOperation((ControlGestureViewModel) commonBindingMoreType2);
                        }
                    }
                    this.this$0.getDataUpdate().postValue(new Pair<>(Boxing.boxInt(4), Boxing.boxBoolean(false)));
                }
                return Unit.INSTANCE;
            }
        }
    }

    private final void updateRightData(ArrayList<ControlConfigurationEntity.Operation> operations) {
        ControlGestureViewModel controlGestureViewModel;
        ControlConfigurationEntity.Operation options;
        Integer num;
        for (CommonBindingMoreType commonBindingMoreType : getRightGestureData()) {
            if ((commonBindingMoreType instanceof ControlGestureViewModel) && (options = (controlGestureViewModel = (ControlGestureViewModel) commonBindingMoreType).getOptions()) != null && (num = controlGestureViewModel.getArrowVisible().get()) != null && num.intValue() == 0) {
                ControlConfigurationEntity.Operation operationCopy$default = ControlConfigurationEntity.Operation.copy$default(options, 0, 0, 0, 0, 15, null);
                operationCopy$default.setOperation(controlGestureViewModel.getDefaultOperation());
                operations.add(operationCopy$default);
            }
        }
    }

    private final void updateLeftData(ArrayList<ControlConfigurationEntity.Operation> operations) {
        ControlGestureViewModel controlGestureViewModel;
        ControlConfigurationEntity.Operation options;
        Integer num;
        for (CommonBindingMoreType commonBindingMoreType : getLeftGestureData()) {
            if ((commonBindingMoreType instanceof ControlGestureViewModel) && (options = (controlGestureViewModel = (ControlGestureViewModel) commonBindingMoreType).getOptions()) != null && (num = controlGestureViewModel.getArrowVisible().get()) != null && num.intValue() == 0) {
                ControlConfigurationEntity.Operation operationCopy$default = ControlConfigurationEntity.Operation.copy$default(options, 0, 0, 0, 0, 15, null);
                operationCopy$default.setOperation(controlGestureViewModel.getDefaultOperation());
                operations.add(operationCopy$default);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetGestureOperation(ControlGestureViewModel it) {
        Integer num = it.getArrowVisible().get();
        if (num != null && num.intValue() == 0) {
            ControlConfigurationEntity.Operation options = it.getOptions();
            if (options != null) {
                options.setOperation(it.getDefaultOperation());
            }
            ControlConfigurationEntity.Operation options2 = it.getOptions();
            Integer numValueOf = options2 != null ? Integer.valueOf(options2.getGesture()) : null;
            if (numValueOf == null || numValueOf.intValue() != 7) {
                if (numValueOf != null && numValueOf.intValue() == 9) {
                    for (ControlOperationViewModel controlOperationViewModel : it.getOperationList()) {
                        controlOperationViewModel.selectedOperation(it.getDefaultOperation() == controlOperationViewModel.getOperation());
                        controlOperationViewModel.getNoiseControlVisible().set(false);
                    }
                } else {
                    for (ControlOperationViewModel controlOperationViewModel2 : it.getOperationList()) {
                        controlOperationViewModel2.selectedOperation(it.getDefaultOperation() == controlOperationViewModel2.getOperation());
                    }
                }
            } else {
                for (ControlOperationViewModel controlOperationViewModel3 : it.getOperationList()) {
                    controlOperationViewModel3.selectedOperation(it.getDefaultOperation() == controlOperationViewModel3.getOperation());
                    if (controlOperationViewModel3.getOperation() == 10 || controlOperationViewModel3.getOperation() == 20 || controlOperationViewModel3.getOperation() == 22 || controlOperationViewModel3.getOperation() == 21) {
                        controlOperationViewModel3.selectedOperation(controlOperationViewModel3.convertAnc(it.getDefaultOperation(), true));
                    } else {
                        controlOperationViewModel3.selectedOperation(it.getDefaultOperation() == controlOperationViewModel3.getOperation());
                        controlOperationViewModel3.getNoiseControlVisible().set(false);
                    }
                }
            }
            it.updateOperationText(it.getDefaultOperation(), this.context);
        }
    }

    private final ControlItemViewModel addSinglePress(ControlConfigurationEntity.Operation operation) {
        if (operation != null) {
            return new ControlItemViewModel(new ControlConfigurationEntity.Operation(operation.getDevice(), operation.getButton(), 1, 2), this.context, getAddress());
        }
        return null;
    }
}
