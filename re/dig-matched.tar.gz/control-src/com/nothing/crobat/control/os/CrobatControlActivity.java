package com.nothing.crobat.control.os;

import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import com.nothing.crobat.control.ControlViewModel;
import com.nothing.earbase.control.ControlGestureViewModel;
import com.nothing.earbase.os.control.OsControlActivity;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: CrobatControlActivity.kt */
/* JADX INFO: loaded from: /tmp/source/classes6.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007\u00a2\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u0007H\u0016\u00a8\u0006\u000b"}, d2 = {"Lcom/nothing/crobat/control/os/CrobatControlActivity;", "Lcom/nothing/earbase/os/control/OsControlActivity;", "<init>", "()V", "getControlViewModel", "Lcom/nothing/crobat/control/ControlViewModel;", "startToOperationActivity", "", "itemViewModel", "Lcom/nothing/earbase/control/ControlGestureViewModel;", "setDefaultSelectBuds", "nt_ear_GoogleStoreRelease"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CrobatControlActivity extends OsControlActivity {
    @Override // com.nothing.earbase.os.control.OsControlActivity
    public ControlViewModel getControlViewModel() {
        return (ControlViewModel) new ViewModelProvider(this).get(ControlViewModel.class);
    }

    @Override // com.nothing.earbase.os.control.OsControlActivity
    public void startToOperationActivity(ControlGestureViewModel itemViewModel) {
        Intrinsics.checkNotNullParameter(itemViewModel, "itemViewModel");
        CrobatControlOperationActivity.Companion companion = CrobatControlOperationActivity.INSTANCE;
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            extras = new Bundle();
        }
        companion.start(extras, this, itemViewModel.getOptions(), false);
    }

    @Override // com.nothing.earbase.os.control.OsControlActivity
    public void setDefaultSelectBuds() {
        getOsViewModel().getTabSelectVisible().set(false);
        getOsViewModel().onClickRightEarBuds();
    }
}
